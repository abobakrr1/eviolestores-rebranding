import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  // GitHub Pages relative base so it works on any repo subpath
  base: './',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
  }
});
