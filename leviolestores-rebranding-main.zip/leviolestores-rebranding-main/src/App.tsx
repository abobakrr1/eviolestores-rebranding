import React, { useState, useMemo } from 'react';
import { TopBanner } from './components/TopBanner';
import { Header } from './components/Header';
import { StoryCircles } from './components/StoryCircles';
import { HeroSlider } from './components/HeroSlider';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { PRODUCTS, Product, CATEGORIES_NAV } from './data/products';
import { useCart } from './context/CartContext';
import {
  SlidersHorizontal,
  ChevronDown,
  Sparkles,
  Flame,
  Percent,
  Check
} from 'lucide-react';

export const App: React.FC = () => {
  const { lang, t } = useCart();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'newest'>('featured');
  const [selectedFabric, setSelectedFabric] = useState<string>('all');
  const [modalProduct, setModalProduct] = useState<Product | null>(null);
  const [showOnlyDeals, setShowOnlyDeals] = useState<boolean>(false);

  // Available fabrics from products
  const fabrics = useMemo(() => {
    return Array.from(new Set(PRODUCTS.map(p => p.material)));
  }, []);

  // Filtered & Sorted products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(product => {
      // Category filter
      if (activeCategory !== 'all') {
        if (activeCategory === 'new-season' && !product.isNew) return false;
        if (activeCategory !== 'new-season' && product.category !== activeCategory) return false;
      }

      // Deals only filter
      if (showOnlyDeals && (!product.discountPercent || product.discountPercent <= 0)) {
        return false;
      }

      // Fabric filter
      if (selectedFabric !== 'all' && product.material !== selectedFabric) {
        return false;
      }

      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchTitleAr = product.title.toLowerCase().includes(query);
        const matchTitleEn = product.titleEn.toLowerCase().includes(query);
        const matchMaterial = product.material.toLowerCase().includes(query);
        const matchCategory = product.categoryLabelAr.toLowerCase().includes(query);
        if (!matchTitleAr && !matchTitleEn && !matchMaterial && !matchCategory) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
      return (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0);
    });
  }, [activeCategory, showOnlyDeals, selectedFabric, searchQuery, sortBy]);

  return (
    <div className="min-h-screen flex flex-col bg-white text-defacto-black">
      {/* 1. Top Bar */}
      <TopBanner />

      {/* 2. DeFacto Header */}
      <Header
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* 3. Story Highlights Circles */}
      <StoryCircles onSelectCategory={setActiveCategory} />

      {/* 4. Hero Fashion Stage Banner */}
      <HeroSlider onCtaClick={setActiveCategory} />

      {/* 5. Main Catalog Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Promotional Banner Strip (DeFacto Red Bar) */}
        <div className="bg-gradient-to-r from-defacto-red to-rose-700 text-white rounded-2xl p-4 sm:p-6 mb-8 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg shadow-defacto-red/20">
          <div className="flex items-center gap-3 text-center sm:text-start">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <Percent className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                عروض تصفيات منتصف الموسم | كود: VOILE10
              </h3>
              <p className="text-xs text-rose-100">
                خصومات تصل إلى 40% على تشكيلات الطرح والعبايات والإسدالات الفاخرة لفترة محدودة.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setShowOnlyDeals(true);
              setActiveCategory('all');
            }}
            className="bg-white text-defacto-red hover:bg-neutral-100 font-extrabold text-xs px-6 py-2.5 rounded-full transition-colors flex-shrink-0 shadow cursor-pointer"
          >
            تصفح التخفيضات الآن
          </button>
        </div>

        {/* Faceted Filter & Sort Control Bar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-neutral-200">
          
          {/* Quick Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full md:w-auto py-1">
            <button
              onClick={() => {
                setActiveCategory('all');
                setShowOnlyDeals(false);
                setSelectedFabric('all');
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeCategory === 'all' && !showOnlyDeals && selectedFabric === 'all'
                  ? 'bg-defacto-black text-white'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              الكل
            </button>

            <button
              onClick={() => setShowOnlyDeals(!showOnlyDeals)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all ${
                showOnlyDeals
                  ? 'bg-defacto-red text-white'
                  : 'bg-red-50 text-defacto-red hover:bg-red-100'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>عروض خاصة</span>
            </button>

            {/* Fabric dropdown filter */}
            <div className="relative inline-block">
              <select
                value={selectedFabric}
                onChange={e => setSelectedFabric(e.target.value)}
                aria-label="Filter by fabric material"
                className="bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold py-1.5 px-3 pe-7 rounded-full appearance-none outline-none cursor-pointer"
              >
                <option value="all">كل الخامات</option>
                {fabrics.map((fab, i) => (
                  <option key={i} value={fab}>
                    {fab}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-neutral-500 absolute end-2 top-2 pointer-events-none" />
            </div>
          </div>

          {/* Results Count & Sort Dropdown */}
          <div className="flex items-center justify-between md:justify-end gap-3 w-full md:w-auto">
            <span className="text-xs text-neutral-500 font-medium">
              {t.resultsFound.replace('{count}', filteredProducts.length.toString())}
            </span>

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-neutral-600 hidden sm:inline">
                {t.sortBy}:
              </span>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                aria-label="Sort products by"
                className="bg-white border border-neutral-300 rounded-lg text-xs font-bold py-1.5 px-3 outline-none focus:border-defacto-black cursor-pointer"
              >
                <option value="featured">{t.sortFeatured}</option>
                <option value="newest">{t.sortNewest}</option>
                <option value="price-low">{t.sortPriceLow}</option>
                <option value="price-high">{t.sortPriceHigh}</option>
              </select>
            </div>
          </div>
        </div>

        {/* Product Grid (DeFacto 4-column responsive) */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6 pt-6">
            {filteredProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={setModalProduct}
              />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
              <SlidersHorizontal className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-neutral-800">
              لا توجد منتجات تطابق اختياراتك
            </h3>
            <p className="text-xs text-neutral-500">
              جربي تغيير معايير البحث أو تصفية الخامات لاستعراض المزيد من القطع.
            </p>
            <button
              onClick={() => {
                setActiveCategory('all');
                setShowOnlyDeals(false);
                setSelectedFabric('all');
                setSearchQuery('');
              }}
              className="mt-2 bg-defacto-black text-white text-xs font-bold px-5 py-2 rounded-full hover:bg-neutral-800"
            >
              {t.clearAll}
            </button>
          </div>
        )}
      </main>

      {/* 6. Quick View Product Modal */}
      <ProductModal
        product={modalProduct}
        onClose={() => setModalProduct(null)}
      />

      {/* 7. Slide-out Cart Drawer */}
      <CartDrawer />

      {/* 8. Modern Footer */}
      <Footer />
    </div>
  );
};
