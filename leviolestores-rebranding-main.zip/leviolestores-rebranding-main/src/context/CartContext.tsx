import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, ProductColor } from '../data/products';
import { translations } from '../data/translations';

export interface CartItem {
  id: string;
  product: Product;
  color: ProductColor;
  size: string;
  quantity: number;
}

interface CartContextType {
  cart: CartItem[];
  wishlist: string[];
  lang: 'ar' | 'en';
  setLang: (lang: 'ar' | 'en') => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  addToCart: (product: Product, color?: ProductColor, size?: string, quantity?: number) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  cartTotal: number;
  cartCount: number;
  discountAmount: number;
  appliedCoupon: string | null;
  applyCoupon: (code: string) => boolean;
  t: typeof translations.ar;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('lv_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('lv_wishlist');
      return saved ? JSON.parse(saved) : ['lv-001', 'lv-003'];
    } catch {
      return ['lv-001', 'lv-003'];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('lv_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('lv_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const addToCart = (product: Product, color?: ProductColor, size?: string, quantity = 1) => {
    const selectedColor = color || product.colors[0];
    const selectedSize = size || product.sizes[0];
    const itemKey = `${product.id}_${selectedColor.hex}_${selectedSize}`;

    setCart(prev => {
      const existing = prev.find(item => item.id === itemKey);
      if (existing) {
        return prev.map(item =>
          item.id === itemKey ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [
        ...prev,
        {
          id: itemKey,
          product,
          color: selectedColor,
          size: selectedSize,
          quantity
        }
      ];
    });

    setIsCartOpen(true);
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    setCart(prev =>
      prev.map(item => (item.id === itemId ? { ...item, quantity } : item))
    );
  };

  const toggleWishlist = (productId: string) => {
    setWishlist(prev =>
      prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]
    );
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const discountAmount = appliedCoupon ? Math.round(cartTotal * 0.1) : 0;

  const applyCoupon = (code: string) => {
    if (code.trim().toUpperCase() === 'VOILE10' || code.trim().toUpperCase() === 'DEFACTO') {
      setAppliedCoupon(code.toUpperCase());
      return true;
    }
    return false;
  };

  const t = translations[lang];

  return (
    <CartContext.Provider
      value={{
        cart,
        wishlist,
        lang,
        setLang,
        isCartOpen,
        setIsCartOpen,
        addToCart,
        removeFromCart,
        updateQuantity,
        toggleWishlist,
        isWishlisted,
        cartTotal,
        cartCount,
        discountAmount,
        appliedCoupon,
        applyCoupon,
        t
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
