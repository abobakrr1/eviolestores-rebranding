export interface ProductColor {
  name: string;
  nameEn: string;
  hex: string;
  image: string;
}

export interface Product {
  id: string;
  title: string;
  titleEn: string;
  category: 'scarves' | 'dresses' | 'isdals' | 'sets' | 'accessories' | 'new-season';
  categoryLabelAr: string;
  categoryLabelEn: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  material: string;
  materialEn: string;
  rating: number;
  reviewsCount: number;
  images: string[];
  colors: ProductColor[];
  sizes: string[];
  isNew?: boolean;
  isBestseller?: boolean;
  isExclusive?: boolean;
  descriptionAr: string;
  descriptionEn: string;
  badge?: string;
  badgeEn?: string;
}

export const PRODUCTS: Product[] = [
  {
    id: 'lv-001',
    title: 'طرحة مودال فاخرة سادة بتأثير مائي ناعم',
    titleEn: 'Fluid Modal Soft Touch Plain Hijab',
    category: 'scarves',
    categoryLabelAr: 'طرح وإيشاربات',
    categoryLabelEn: 'Scarves & Hijabs',
    price: 385,
    originalPrice: 550,
    discountPercent: 30,
    material: 'مودال تركي طبيعي',
    materialEn: 'Natural Turkish Modal',
    rating: 4.9,
    reviewsCount: 142,
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1609357605129-26f69add5d6e?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'كافيه ناعم', nameEn: 'Soft Latte', hex: '#C2A385', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop' },
      { name: 'زيتي هادئ', nameEn: 'Sage Olive', hex: '#606E5A', image: 'https://images.unsplash.com/photo-1609357605129-26f69add5d6e?q=80&w=800&auto=format&fit=crop' },
      { name: 'أسود ملكي', nameEn: 'Royal Black', hex: '#1C1C1C', image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?q=80&w=800&auto=format&fit=crop' },
      { name: 'وردي باودر', nameEn: 'Powder Rose', hex: '#E2B8B8', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['75 × 195 سم'],
    isNew: true,
    isBestseller: true,
    descriptionAr: 'طرحة المودال الأشهر من لو فوال، خامة خفيفة ناعمة للغاية ومريحة للارتداء طوال اليوم دون أن تنزلق، تمنحك إطلالة راقية وثابتة بلمسة حريرية مطفية.',
    descriptionEn: 'The iconic Le Voile Modal scarf, lightweight, breathable and perfectly non-slip. Delivers quiet luxury aesthetics with a matte finish.',
    badge: 'الأكثر طلباً',
    badgeEn: 'Best Seller'
  },
  {
    id: 'lv-002',
    title: 'فستان شيفون مطوي كاجوال بأكمام واسعة',
    titleEn: 'Pleated Chiffon Modest Maxi Dress',
    category: 'dresses',
    categoryLabelAr: 'فساتين ودريسات',
    categoryLabelEn: 'Dresses',
    price: 1450,
    originalPrice: 2200,
    discountPercent: 34,
    material: 'شيفون جورجيت وبطانة قطنية',
    materialEn: 'Georgette Chiffon & Cotton Lining',
    rating: 4.8,
    reviewsCount: 88,
    images: [
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'أزرق كحلي', nameEn: 'Navy Blue', hex: '#172B4D', image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop' },
      { name: 'عنابي دافئ', nameEn: 'Burgundy', hex: '#631D28', image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    isNew: true,
    descriptionAr: 'تصميم أنثوي محتشم وراقي بقصات بليسيه واسعة ولمسات مطاطية ناعمة على المعصم، مثالي للمناسبات الصباحية والزيارات الخاصة.',
    descriptionEn: 'Elegant modest silhouette with delicate pleats and balloon sleeves, fully lined with high grade breathable fabric.',
    badge: 'عرض حصري',
    badgeEn: 'Exclusive'
  },
  {
    id: 'lv-003',
    title: 'إسدال صلاة رويال كريب بتطريز كم فاخر وسوستة خفية',
    titleEn: 'Royal Crepe Embroidered Prayer Isdal',
    category: 'isdals',
    categoryLabelAr: 'إسدالات الصلاة',
    categoryLabelEn: 'Prayer Isdals',
    price: 890,
    originalPrice: 1190,
    discountPercent: 25,
    material: 'كريب كوري بارد',
    materialEn: 'Korean Cool Crepe',
    rating: 5.0,
    reviewsCount: 210,
    images: [
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'زمردي داكن', nameEn: 'Emerald Green', hex: '#0B4734', image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800&auto=format&fit=crop' },
      { name: 'رمادي فضي', nameEn: 'Silver Grey', hex: '#A8A9AD', image: 'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=800&auto=format&fit=crop' },
      { name: 'موف داكن', nameEn: 'Plum Violet', hex: '#4B244A', image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['Free Size (مناسب لجميع المقاسات)'],
    isBestseller: true,
    descriptionAr: 'خامة الكريب الملكي المقاومة للتجعد مع طرحة متصلة واسعة وقفل سوستة أمامي مريح. تطريز خيط حريري ناعم على الأساور.',
    descriptionEn: 'Wrinkle-resistant royal crepe prayer dress featuring attached wrap scarf and concealed front zip for effortless comfort.',
    badge: 'الأكثر مبيعاً',
    badgeEn: 'Top Choice'
  },
  {
    id: 'lv-004',
    title: 'طقم كتان أنيق قطعتين (قميص كيمونو وبنطلون واسع)',
    titleEn: 'Two-Piece Linen Kimono & Wide Pants Set',
    category: 'sets',
    categoryLabelAr: 'أطقم وكوردينيت',
    categoryLabelEn: 'Co-ord Sets',
    price: 1850,
    originalPrice: 2450,
    discountPercent: 24,
    material: 'كتان إيطالي نقي 100%',
    materialEn: '100% Pure Italian Linen',
    rating: 4.7,
    reviewsCount: 64,
    images: [
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'رملي طبيعي', nameEn: 'Natural Sand', hex: '#D7C4A5', image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop' },
      { name: 'أبيض عاجي', nameEn: 'Off-White', hex: '#FAF9F6', image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['S/M', 'L/XL'],
    isNew: true,
    descriptionAr: 'طقم عملي وشديد العصرية من الكتان الطبيعي المريح، يمنحك تهوية فائقة وشياكة هادئة تلائم خروجات الصيف والسفر.',
    descriptionEn: 'Sophisticated relaxed linen set with buttoned kimono top and elasticated wide-leg trousers.',
    badge: 'جديد الموسم',
    badgeEn: 'New In'
  },
  {
    id: 'lv-005',
    title: 'بندانة قطن ليكرا ناعمة بتغطية كاملة وشريط مانع للانزلاق',
    titleEn: 'Cotton Lycra Full Coverage Non-Slip Inner Cap',
    category: 'accessories',
    categoryLabelAr: 'إكسسوارات وبندانات',
    categoryLabelEn: 'Accessories & Inners',
    price: 95,
    originalPrice: 140,
    discountPercent: 32,
    material: 'قطن مصري 95% + ليكرا 5%',
    materialEn: '95% Egyptian Cotton + 5% Lycra',
    rating: 4.9,
    reviewsCount: 380,
    images: [
      'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'أسود', nameEn: 'Black', hex: '#111111', image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=800&auto=format&fit=crop' },
      { name: 'بيج نيود', nameEn: 'Beige Nude', hex: '#E6D3B3', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop' },
      { name: 'أبيض ناصع', nameEn: 'White', hex: '#FFFFFF', image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['مقاس موحد'],
    isBestseller: true,
    descriptionAr: 'البندانة الأساسية لكل محجبة، مصممة بطبقة داخلية تمنع انزلاق الطرحة نهائياً وتمنع الصداع بفضل المرونة الطبيعية.',
    descriptionEn: 'Essential non-slip underscarf cap with ergonomic ear comfort and high breathability.',
    badge: 'قطعة أساسية',
    badgeEn: 'Essential'
  },
  {
    id: 'lv-006',
    title: 'طرحة شيفون بيور مطبوعة ديجيتال بنقشات حصرية',
    titleEn: 'Digital Printed Pure Chiffon Shawl',
    category: 'scarves',
    categoryLabelAr: 'طرح وإيشاربات',
    categoryLabelEn: 'Scarves & Hijabs',
    price: 340,
    originalPrice: 480,
    discountPercent: 29,
    material: 'شيفون كريب تركي عالي الجودة',
    materialEn: 'Turkish Chiffon Crepe',
    rating: 4.8,
    reviewsCount: 95,
    images: [
      'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'نقوشات فلورال ناعمة', nameEn: 'Soft Floral', hex: '#E7BDC8', image: 'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?q=80&w=800&auto=format&fit=crop' },
      { name: 'ماربل تجريدي', nameEn: 'Abstract Marble', hex: '#B8C5D6', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['70 × 190 سم'],
    isNew: true,
    descriptionAr: 'طباعة حرارية رقمية فائقة الوضوح مع ثبات ألوان يدوم طويلاً، قماش شيفون انسيابي خفيف ومقاوم للتكسير.',
    descriptionEn: 'Ultra high-definition digital botanical prints on silky chiffon crepe. Lightweight and easy to drape.',
    badge: 'تشكيلة جديدة',
    badgeEn: 'New Drop'
  },
  {
    id: 'lv-007',
    title: 'عباية كيمونو كلاسيك بأكمام حريرية مطرزة',
    titleEn: 'Classic Open Kimono Abaya with Silk Trim',
    category: 'dresses',
    categoryLabelAr: 'فساتين وعبايات',
    categoryLabelEn: 'Dresses & Abayas',
    price: 2100,
    originalPrice: 2800,
    discountPercent: 25,
    material: 'كريب صالونة ياباني نخب أول',
    materialEn: 'Premium Japanese Salona Crepe',
    rating: 4.9,
    reviewsCount: 52,
    images: [
      'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'أسود فحمي', nameEn: 'Charcoal Black', hex: '#111111', image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?q=80&w=800&auto=format&fit=crop' },
      { name: 'بني شوكولاتة', nameEn: 'Chocolate Brown', hex: '#442C22', image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['52', '54', '56', '58'],
    isExclusive: true,
    descriptionAr: 'قطعة أنيقة تعكس الفخامة الهادئة بأسلوب عصري محتشم، تأتي مع حزام خصر متطابق وطرحة شيفون هدية.',
    descriptionEn: 'Understated luxury open abaya crafted from jet black Japanese crepe with refined sleeve cuffs. Includes matching belt and scarf.',
    badge: 'إصدار فاخر',
    badgeEn: 'Premium'
  },
  {
    id: 'lv-008',
    title: 'مجموعة مشابك حجاب مغناطيسية ضد تلف الأقمشة (4 أزواج)',
    titleEn: 'Ultra-Strong Magnetic Hijab Pins Pack (4 Pairs)',
    category: 'accessories',
    categoryLabelAr: 'إكسسوارات وبندانات',
    categoryLabelEn: 'Accessories & Inners',
    price: 195,
    originalPrice: 280,
    discountPercent: 30,
    material: 'مغناطيس نيوديميوم قوي ومطلي',
    materialEn: 'Neodymium Plated Magnets',
    rating: 5.0,
    reviewsCount: 312,
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?q=80&w=800&auto=format&fit=crop'
    ],
    colors: [
      { name: 'مكس معدني (ذهبي، فضي، وردي، أسود)', nameEn: 'Metallic Mix', hex: '#D4AF37', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?q=80&w=800&auto=format&fit=crop' }
    ],
    sizes: ['حجم صغير فائق القوة'],
    isBestseller: true,
    descriptionAr: 'وداعاً لثقوب الدبابيس وتمزق أقمشة الشيفون والحرير! مغناطيس فائق القوة يثبت الحجاب بإحكام طوال اليوم دون ترك أي أثر.',
    descriptionEn: 'Say goodbye to pin holes! Ultra-strong snag-free magnetic clips preserve your delicate modal, silk and chiffon scarves.',
    badge: 'الأكثر مبيعاً',
    badgeEn: 'Best Seller'
  }
];

export const CATEGORIES_NAV = [
  { id: 'all', nameAr: 'جميع المنتجات', nameEn: 'All Products', icon: 'Sparkles' },
  { id: 'scarves', nameAr: 'طرح وإيشاربات', nameEn: 'Scarves & Hijabs', icon: 'Feather', count: 180 },
  { id: 'dresses', nameAr: 'فساتين وعبايات', nameEn: 'Dresses & Abayas', icon: 'Shirt', count: 95 },
  { id: 'isdals', nameAr: 'إسدالات الصلاة', nameEn: 'Prayer Isdals', icon: 'Heart', count: 42 },
  { id: 'sets', nameAr: 'أطقم وكوردينيت', nameEn: 'Co-ord Sets', icon: 'Layers', count: 68 },
  { id: 'accessories', nameAr: 'إكسسوارات وبندانات', nameEn: 'Accessories & Inners', icon: 'Gem', count: 120 },
  { id: 'new-season', nameAr: 'جديد الموسم ✨', nameEn: 'New In ✨', icon: 'Flame', count: 45 }
];

export const STORIES = [
  { id: 1, titleAr: 'جديد مودال', titleEn: 'New Modal', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=300&auto=format&fit=crop', category: 'scarves' },
  { id: 2, titleAr: 'عروض 40%', titleEn: 'Sale 40%', image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=300&auto=format&fit=crop', category: 'all', isSale: true },
  { id: 3, titleAr: 'إسدالات رويال', titleEn: 'Royal Isdal', image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=300&auto=format&fit=crop', category: 'isdals' },
  { id: 4, titleAr: 'كتان الصيف', titleEn: 'Summer Linen', image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=300&auto=format&fit=crop', category: 'sets' },
  { id: 5, titleAr: 'بندانات سرية', titleEn: 'Inner Magic', image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=300&auto=format&fit=crop', category: 'accessories' },
  { id: 6, titleAr: 'شيفون ديجيتال', titleEn: 'Chiffon Prints', image: 'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?q=80&w=300&auto=format&fit=crop', category: 'scarves' }
];
