import React from 'react';
import { useCart } from '../context/CartContext';
import {
  Truck,
  RotateCcw,
  CreditCard,
  PhoneCall,
  Instagram,
  Facebook,
  Send,
  CheckCircle2
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { lang, t } = useCart();

  return (
    <footer className="bg-neutral-900 text-neutral-300 pt-12 pb-8 border-t border-neutral-800">
      {/* Trust Guarantees Bar (DeFacto signature) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10 border-b border-neutral-800">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-neutral-800/50">
            <Truck className="w-6 h-6 text-defacto-red flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm text-white">{t.guarantees.returnTitle}</h4>
              <p className="text-xs text-neutral-400 mt-0.5">{t.guarantees.returnDesc}</p>
            </div>
          </div>
          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-neutral-800/50">
            <RotateCcw className="w-6 h-6 text-defacto-red flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm text-white">{t.guarantees.codTitle}</h4>
              <p className="text-xs text-neutral-400 mt-0.5">{t.guarantees.codDesc}</p>
            </div>
          </div>
          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-neutral-800/50">
            <CheckCircle2 className="w-6 h-6 text-defacto-red flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm text-white">{t.guarantees.qualityTitle}</h4>
              <p className="text-xs text-neutral-400 mt-0.5">{t.guarantees.qualityDesc}</p>
            </div>
          </div>
          <div className="flex items-start gap-3.5 p-4 rounded-xl bg-neutral-800/50">
            <CreditCard className="w-6 h-6 text-defacto-red flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm text-white">طرق دفع متعددة</h4>
              <p className="text-xs text-neutral-400 mt-0.5">فيزا، ماستركارد، ميزة، ڤاليو، أمان</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Newsletter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-1.5">
              <span className="font-montserrat font-black text-2xl tracking-tight text-white">
                LE VOILE
              </span>
              <span className="w-2 h-2 rounded-full bg-defacto-red"></span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              {t.footer.aboutDesc}
            </p>
            
            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://www.instagram.com/levoilestores/"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-neutral-800 hover:bg-defacto-red text-white flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://www.facebook.com/levoilestores/"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-neutral-800 hover:bg-defacto-red text-white flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="tel:19999"
                className="w-9 h-9 rounded-full bg-neutral-800 hover:bg-defacto-red text-white flex items-center justify-center transition-colors"
                aria-label="Call hotline"
              >
                <PhoneCall className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links 1 */}
          <div>
            <h4 className="font-bold text-sm text-white mb-4 uppercase tracking-wider">
              {t.footer.shopLinks}
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              <li><a href="#scarves" className="hover:text-white transition-colors">طرح المودال والشيفون</a></li>
              <li><a href="#dresses" className="hover:text-white transition-colors">فساتين بليسيه ودريسات</a></li>
              <li><a href="#isdals" className="hover:text-white transition-colors">إسدالات رويال كريب</a></li>
              <li><a href="#sets" className="hover:text-white transition-colors">أطقم الكتان والكوردينيت</a></li>
              <li><a href="#accessories" className="hover:text-white transition-colors">مشابك مغناطيس وبندانات</a></li>
            </ul>
          </div>

          {/* Quick Links 2 */}
          <div>
            <h4 className="font-bold text-sm text-white mb-4 uppercase tracking-wider">
              {t.footer.customerCare}
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-400">
              <li><a href="#" className="hover:text-white transition-colors">سياسة الاستبدال والاسترجاع</a></li>
              <li><a href="#" className="hover:text-white transition-colors">دليل المقاسات والعناية بالأقمشة</a></li>
              <li><a href="#" className="hover:text-white transition-colors">فروع لو فوال في مصر</a></li>
              <li><a href="#" className="hover:text-white transition-colors">تتبع الشحنة</a></li>
              <li><a href="#" className="hover:text-white transition-colors">الأسئلة الشائعة</a></li>
            </ul>
          </div>

          {/* Newsletter (DeFacto Style) */}
          <div>
            <h4 className="font-bold text-sm text-white mb-2">
              {t.footer.newsletterTitle}
            </h4>
            <p className="text-xs text-neutral-400 mb-3">
              {t.footer.newsletterDesc}
            </p>
            <form onSubmit={e => { e.preventDefault(); alert('شكراً لاشتراكك في نشرة لو فوال!'); }} className="space-y-2">
              <input
                type="email"
                required
                placeholder={t.footer.newsletterPlaceholder}
                className="w-full bg-neutral-800 border border-neutral-700 rounded-lg text-xs py-2.5 px-3 text-white placeholder-neutral-500 outline-none focus:border-defacto-red"
              />
              <button
                type="submit"
                className="w-full bg-defacto-red hover:bg-defacto-darkRed text-white font-bold text-xs py-2.5 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>{t.footer.subscribe}</span>
                <Send className="w-3 h-3" />
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Bottom Copyright & Payment Methods */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
        <p>{t.footer.allRights}</p>
        
        {/* Payment Icons */}
        <div className="flex items-center gap-2 text-xs font-bold text-neutral-400">
          <span className="bg-neutral-800 px-2 py-1 rounded">VISA</span>
          <span className="bg-neutral-800 px-2 py-1 rounded">Mastercard</span>
          <span className="bg-neutral-800 px-2 py-1 rounded">Meeza</span>
          <span className="bg-neutral-800 px-2 py-1 rounded">valU</span>
          <span className="bg-neutral-800 px-2 py-1 rounded">الدفع عند الاستلام</span>
        </div>
      </div>
    </footer>
  );
};
