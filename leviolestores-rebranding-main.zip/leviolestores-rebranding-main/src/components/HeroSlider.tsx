import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { ChevronRight, ChevronLeft, Sparkles, ArrowRight, ArrowLeft } from 'lucide-react';

interface HeroSliderProps {
  onCtaClick: (category: string) => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({ onCtaClick }) => {
  const { lang, t } = useCart();
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      badgeAr: 'التشكيلة الجديدة 2026',
      badgeEn: 'New Collection 2026',
      titleAr: 'طرح المودال والشيفون الفاخر',
      titleEn: 'Luxury Modal & Chiffon Drapes',
      descAr: 'لمسات هادئة وملمس ناعم كالحرير لا ينزلق لتتألقي في كل إطلالة يومية.',
      descEn: 'Quiet luxury aesthetics with breathable textures engineered to stay put all day.',
      ctaTextAr: 'تسوقي الطرح الآن',
      ctaTextEn: 'Shop Scarves Now',
      category: 'scarves',
      bgGradient: 'from-amber-950/70 to-neutral-950/60',
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=1600&auto=format&fit=crop'
    },
    {
      id: 2,
      badgeAr: 'عروض ديفاكتو ستايل | حتى 40% خصم',
      badgeEn: 'DeFacto Style Deals | Up to 40% OFF',
      titleAr: 'أناقة الحجاب بأفضل الأسعار التنافسية',
      titleEn: 'Modest Elegance at Unbeatable Prices',
      descAr: 'إسدالات رويال كريب، فساتين أنيقة، وأطقم كتان مميزة متوفرة بكميات محدودة.',
      descEn: 'Royal crepe prayer isdals, pleated chiffon dresses, and tailored linen sets.',
      ctaTextAr: 'اكتشفي عروض التخفيضات',
      ctaTextEn: 'Discover Sale Deals',
      category: 'all',
      bgGradient: 'from-rose-950/70 to-black/70',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1600&auto=format&fit=crop'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const slide = slides[currentSlide];

  return (
    <div className="relative w-full overflow-hidden bg-neutral-900 text-white h-[360px] sm:h-[450px] lg:h-[500px]">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000 transform scale-105"
        style={{ backgroundImage: `url(${slide.image})` }}
      >
        <div className={`absolute inset-0 bg-gradient-to-r ${slide.bgGradient}`} />
      </div>

      {/* Content Container */}
      <div className="relative max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
        <div className="max-w-xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{lang === 'ar' ? slide.badgeAr : slide.badgeEn}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black leading-tight tracking-tight">
            {lang === 'ar' ? slide.titleAr : slide.titleEn}
          </h1>

          <p className="text-sm sm:text-base text-neutral-200 line-clamp-2">
            {lang === 'ar' ? slide.descAr : slide.descEn}
          </p>

          <div className="pt-2">
            <button
              onClick={() => onCtaClick(slide.category)}
              className="inline-flex items-center gap-2 bg-defacto-red hover:bg-defacto-darkRed text-white px-7 py-3 rounded-full font-bold text-sm tracking-wide shadow-lg shadow-defacto-red/30 transition-all transform hover:-translate-y-0.5 cursor-pointer"
            >
              <span>{lang === 'ar' ? slide.ctaTextAr : slide.ctaTextEn}</span>
              {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Slider Controls */}
      <button
        onClick={() => setCurrentSlide((currentSlide - 1 + slides.length) % slides.length)}
        className="absolute start-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs transition-colors"
        aria-label="Previous slide"
      >
        <ChevronRight className="w-5 h-5 rtl:rotate-180" />
      </button>

      <button
        onClick={() => setCurrentSlide((currentSlide + 1) % slides.length)}
        className="absolute end-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs transition-colors"
        aria-label="Next slide"
      >
        <ChevronLeft className="w-5 h-5 rtl:rotate-180" />
      </button>

      {/* Indicators */}
      <div className="absolute bottom-4 start-1/2 -translate-x-1/2 flex items-center gap-2">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-2 rounded-full transition-all ${
              currentSlide === idx ? 'w-8 bg-defacto-red' : 'w-2 bg-white/50 hover:bg-white'
            }`}
            aria-label={`Slide ${idx + 1}`}
          />
        ))}
      </div>
    </div>
  );
};
