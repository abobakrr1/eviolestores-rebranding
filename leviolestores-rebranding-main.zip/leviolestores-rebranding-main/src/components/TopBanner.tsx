import React from 'react';
import { useCart } from '../context/CartContext';
import { Smartphone, Globe } from 'lucide-react';

export const TopBanner: React.FC = () => {
  const { lang, setLang, t } = useCart();

  return (
    <div className="bg-defacto-black text-white text-xs border-b border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex flex-col md:flex-row items-center justify-between gap-2">
        {/* Promo message with subtle glow */}
        <div className="flex items-center gap-2 text-center md:text-start font-medium text-neutral-200">
          <span className="bg-defacto-red text-white text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider animate-pulse-badge">
            عرض خاص
          </span>
          <span>{t.topPromo}</span>
        </div>

        {/* Quick Links & Language Toggle */}
        <div className="flex items-center gap-4 text-neutral-300">
          <button
            onClick={() => alert(t.appDownload)}
            className="hidden sm:flex items-center gap-1.5 hover:text-white transition-colors"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{t.appDownload}</span>
          </button>
          <span className="hidden sm:inline text-neutral-600">|</span>
          <button
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            className="flex items-center gap-1 font-semibold text-white hover:text-defacto-red transition-colors cursor-pointer bg-neutral-800 px-2 py-0.5 rounded"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'English (EN)' : 'العربية (AR)'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
