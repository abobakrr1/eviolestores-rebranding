import React from 'react';
import { STORIES } from '../data/products';
import { useCart } from '../context/CartContext';

interface StoryCirclesProps {
  onSelectCategory: (cat: string) => void;
}

export const StoryCircles: React.FC<StoryCirclesProps> = ({ onSelectCategory }) => {
  const { lang } = useCart();

  return (
    <div className="bg-neutral-50/70 border-b border-defacto-border py-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4 sm:gap-6 overflow-x-auto no-scrollbar py-1">
          {STORIES.map(story => (
            <button
              key={story.id}
              onClick={() => onSelectCategory(story.category)}
              className="flex flex-col items-center gap-2 group flex-shrink-0 focus:outline-none"
            >
              {/* Instagram / DeFacto Story Ring */}
              <div className="p-0.5 rounded-full bg-gradient-to-tr from-defacto-red via-levoile-purple to-amber-500 group-hover:scale-105 transition-transform">
                <div className="p-0.5 bg-white rounded-full">
                  <img
                    src={story.image}
                    alt={story.titleAr}
                    className="w-16 h-16 sm:w-18 sm:h-18 rounded-full object-cover group-hover:opacity-90 transition-opacity"
                  />
                </div>
              </div>
              <span className="text-xs font-bold text-neutral-800 group-hover:text-defacto-red transition-colors text-center max-w-[76px] truncate">
                {lang === 'ar' ? story.titleAr : story.titleEn}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
