import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { X, Trash2, ShoppingBag, ArrowRight, ArrowLeft, Truck, Tag, ShieldCheck } from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    cartTotal,
    discountAmount,
    appliedCoupon,
    applyCoupon,
    lang,
    t
  } = useCart();

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState(false);

  if (!isCartOpen) return null;

  const FREE_SHIPPING_THRESHOLD = 1000;
  const remainingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - cartTotal);
  const freeShippingProgress = Math.min(100, (cartTotal / FREE_SHIPPING_THRESHOLD) * 100);
  const shippingFee = cartTotal >= FREE_SHIPPING_THRESHOLD || cartTotal === 0 ? 0 : 50;
  const finalTotal = Math.max(0, cartTotal - discountAmount + shippingFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const success = applyCoupon(couponInput);
    if (!success) {
      setCouponError(true);
      setTimeout(() => setCouponError(false), 3000);
    } else {
      setCouponInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 end-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col animate-in slide-in-from-end duration-300">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-defacto-black" />
              <h2 className="text-base sm:text-lg font-bold text-defacto-black">
                {t.cart} ({cart.reduce((sum, i) => sum + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Free Shipping Progress Bar */}
          <div className="bg-neutral-50 p-3.5 border-b border-neutral-200">
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-700 mb-2">
              <Truck className="w-4 h-4 text-defacto-red flex-shrink-0" />
              <span>
                {remainingForFreeShipping > 0
                  ? t.freeShippingNotice.replace('{amount}', remainingForFreeShipping.toString())
                  : t.freeShippingQualified}
              </span>
            </div>
            <div className="w-full bg-neutral-200 rounded-full h-2 overflow-hidden">
              <div
                className="bg-defacto-red h-2 rounded-full transition-all duration-500"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center text-neutral-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-neutral-800 mb-1">{t.cartEmpty}</h3>
                  <p className="text-xs text-neutral-500 max-w-xs">
                    استكشفي أحدث تشكيلات الطرح والفساتين والإسدالات وأضيفي قطعك المفضلة.
                  </p>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="bg-defacto-black text-white text-xs font-bold px-6 py-2.5 rounded-full hover:bg-neutral-800 transition-colors"
                >
                  {t.continueShopping}
                </button>
              </div>
            ) : (
              cart.map(item => (
                <div
                  key={item.id}
                  className="flex gap-3 bg-neutral-50/70 p-3 rounded-xl border border-neutral-100 relative group"
                >
                  {/* Thumbnail */}
                  <img
                    src={item.color.image || item.product.images[0]}
                    alt=""
                    className="w-20 h-24 object-cover rounded-lg bg-white flex-shrink-0"
                  />

                  {/* Info */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start gap-2">
                        <h4 className="text-xs font-bold text-neutral-800 line-clamp-1">
                          {lang === 'ar' ? item.product.title : item.product.titleEn}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-neutral-400 hover:text-defacto-red transition-colors p-0.5"
                          title="حذف"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 mt-1 text-[11px] text-neutral-500">
                        <span className="flex items-center gap-1">
                          <span
                            className="w-2.5 h-2.5 rounded-full border"
                            style={{ backgroundColor: item.color.hex }}
                          />
                          {lang === 'ar' ? item.color.name : item.color.nameEn}
                        </span>
                        <span>•</span>
                        <span>{item.size}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <span className="font-extrabold text-sm text-defacto-black">
                        {item.product.price * item.quantity} {t.egp}
                      </span>

                      {/* Quantity Controls */}
                      <div className="flex items-center border border-neutral-300 rounded-lg bg-white">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-7 h-7 flex items-center justify-center text-xs font-bold hover:bg-neutral-100"
                        >
                          -
                        </button>
                        <span className="w-7 text-center text-xs font-bold">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-7 h-7 flex items-center justify-center text-xs font-bold hover:bg-neutral-100"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Area */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-neutral-200 bg-neutral-50/50 space-y-3">
              {/* Coupon Form */}
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={couponInput}
                    onChange={e => setCouponInput(e.target.value)}
                    placeholder={t.couponCode}
                    className="w-full bg-white border border-neutral-300 rounded-lg text-xs py-2 px-3 outline-none focus:border-defacto-black"
                  />
                  <Tag className="w-3.5 h-3.5 text-neutral-400 absolute end-2.5 top-2.5 pointer-events-none" />
                </div>
                <button
                  type="submit"
                  className="bg-neutral-800 hover:bg-defacto-black text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors"
                >
                  {t.apply}
                </button>
              </form>

              {appliedCoupon && (
                <div className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded p-2 flex justify-between items-center">
                  <span>تم تطبيق كود الخصم: <strong>{appliedCoupon}</strong> (-10%)</span>
                  <span className="font-bold">-{discountAmount} {t.egp}</span>
                </div>
              )}

              {couponError && (
                <div className="text-xs text-defacto-red bg-red-50 p-2 rounded">
                  كود غير صالح. جربي كود: <strong>VOILE10</strong>
                </div>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-neutral-600 pt-1">
                <div className="flex justify-between">
                  <span>{t.subtotal}</span>
                  <span className="font-semibold text-neutral-800">{cartTotal} {t.egp}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>خصم الكوبون</span>
                    <span>-{discountAmount} {t.egp}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>{t.shipping}</span>
                  <span className={shippingFee === 0 ? 'text-emerald-600 font-bold' : 'font-semibold'}>
                    {shippingFee === 0 ? t.free : `${shippingFee} ${t.egp}`}
                  </span>
                </div>
                <div className="flex justify-between text-base font-black text-defacto-black pt-2 border-t border-neutral-200">
                  <span>{t.total}</span>
                  <span className="text-defacto-red">{finalTotal} {t.egp}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={() => alert(`شكراً لتسوقك! سيتم نقلك لبوابة الدفع الآمنة بقيمة ${finalTotal} ج.م`)}
                className="w-full bg-defacto-red hover:bg-defacto-darkRed text-white font-bold text-sm py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-defacto-red/30 transition-all cursor-pointer"
              >
                <span>{t.checkout}</span>
                {lang === 'ar' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-neutral-400 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-neutral-500" />
                <span>دفع إلكتروني مشفر وآمن 100% أو عند الاستلام</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
