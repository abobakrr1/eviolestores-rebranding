import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { CATEGORIES_NAV } from '../data/products';
import {
  Search,
  ShoppingBag,
  Heart,
  User,
  Menu,
  X
} from 'lucide-react';

interface HeaderProps {
  activeCategory: string;
  onSelectCategory: (catId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeCategory,
  onSelectCategory,
  searchQuery,
  setSearchQuery
}) => {
  const { cartCount, wishlist, setIsCartOpen, t } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-defacto-border">
      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4 md:gap-8">
          
          {/* Mobile Menu Trigger & Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-2 rounded-lg text-neutral-700 hover:bg-neutral-100"
              aria-label="Open menu"
            >
              <Menu className="w-6 h-6" />
            </button>

            {/* DeFacto-Style Bold Brand Logo */}
            <div
              onClick={() => onSelectCategory('all')}
              className="cursor-pointer group flex flex-col items-start"
            >
              <div className="flex items-center gap-1.5">
                <span className="font-montserrat font-extrabold text-2xl tracking-tighter text-defacto-black group-hover:text-defacto-red transition-colors">
                  LE VOILE
                </span>
                <span className="w-2 h-2 rounded-full bg-defacto-red"></span>
              </div>
              <span className="text-[10px] tracking-widest text-neutral-400 font-semibold uppercase -mt-1">
                {t.brandSubtitle}
              </span>
            </div>
          </div>

          {/* DeFacto-style Search Bar with autocomplete dropdown */}
          <div className="flex-1 max-w-2xl relative hidden sm:block">
            <div className="relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                placeholder={t.searchPlaceholder}
                className="w-full bg-defacto-gray border border-transparent focus:border-defacto-black focus:bg-white text-sm rounded-full py-2.5 px-10 outline-none transition-all"
              />
              <Search className="w-4 h-4 text-neutral-400 absolute start-3.5 pointer-events-none" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute end-3.5 text-neutral-400 hover:text-neutral-700"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Search Suggestions Popup */}
            {isSearchFocused && (
              <div className="absolute top-full start-0 end-0 mt-2 bg-white rounded-2xl shadow-xl border border-defacto-border p-4 z-50">
                <div className="text-xs font-semibold text-neutral-400 mb-2">
                  {t.searchSuggestions}
                </div>
                <div className="flex flex-wrap gap-2">
                  {t.suggestionTags.map((tag, i) => (
                    <button
                      key={i}
                      onMouseDown={() => setSearchQuery(tag)}
                      className="text-xs bg-neutral-100 hover:bg-defacto-red hover:text-white text-neutral-700 px-3 py-1.5 rounded-full transition-colors"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Action Icons */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Account */}
            <button
              onClick={() => alert('تسجيل الدخول / Login')}
              className="flex items-center gap-1.5 text-neutral-700 hover:text-defacto-red p-2 rounded-lg transition-colors"
            >
              <User className="w-5 h-5" />
              <span className="hidden lg:inline text-xs font-medium">{t.login}</span>
            </button>

            {/* Wishlist */}
            <button
              onClick={() => alert(`المفضلة (${wishlist.length} منتجات)`)}
              className="relative p-2 text-neutral-700 hover:text-defacto-red transition-colors"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 end-1 bg-defacto-red text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full font-bold">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="flex items-center gap-2 bg-defacto-black hover:bg-neutral-800 text-white px-4 py-2.5 rounded-full transition-all relative"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline text-xs font-bold">{t.cart}</span>
              <span className="bg-defacto-red text-white text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Search input */}
        <div className="pb-3 sm:hidden">
          <div className="relative flex items-center">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-defacto-gray text-xs rounded-full py-2 px-9 outline-none focus:bg-white focus:border focus:border-defacto-black"
            />
            <Search className="w-4 h-4 text-neutral-400 absolute start-3 pointer-events-none" />
          </div>
        </div>

        {/* Categories Strip Navigation */}
        <nav className="hidden md:flex items-center justify-start gap-1 border-t border-neutral-100 overflow-x-auto no-scrollbar">
          {CATEGORIES_NAV.map(cat => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`py-3 px-4 text-xs font-bold whitespace-nowrap transition-all border-b-2 ${
                  isActive
                    ? 'border-defacto-red text-defacto-red'
                    : 'border-transparent text-neutral-600 hover:text-defacto-black hover:border-neutral-300'
                }`}
              >
                {cat.nameAr}
                {cat.count && (
                  <span className="ms-1.5 text-[10px] text-neutral-400 font-normal">
                    ({cat.count})
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-4/5 max-w-xs bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-start duration-200">
            <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
              <div className="font-extrabold text-lg text-defacto-black">
                LE VOILE <span className="text-defacto-red">•</span>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 rounded-md text-neutral-400 hover:text-neutral-700"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-4 overflow-y-auto flex-1 space-y-1">
              <div className="text-xs font-bold text-neutral-400 mb-2 uppercase tracking-wider">
                {t.categories}
              </div>
              {CATEGORIES_NAV.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => {
                    onSelectCategory(cat.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full text-start py-3 px-3 rounded-xl text-sm font-semibold flex items-center justify-between ${
                    activeCategory === cat.id
                      ? 'bg-neutral-100 text-defacto-red'
                      : 'text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  <span>{cat.nameAr}</span>
                  {cat.count && (
                    <span className="text-xs text-neutral-400 bg-neutral-100 px-2 py-0.5 rounded-full">
                      {cat.count}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
