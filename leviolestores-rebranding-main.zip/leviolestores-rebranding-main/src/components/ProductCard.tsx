import React, { useState } from 'react';
import { Product, ProductColor } from '../data/products';
import { useCart } from '../context/CartContext';
import { Heart, Eye, ShoppingBag, Star, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { lang, addToCart, toggleWishlist, isWishlisted, t } = useCart();
  const [selectedColor, setSelectedColor] = useState<ProductColor>(product.colors[0]);
  const [isHovered, setIsHovered] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const displayImage = isHovered && product.images[1] ? product.images[1] : selectedColor.image;
  const wishlisted = isWishlisted(product.id);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, selectedColor, product.sizes[0], 1);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1500);
  };

  return (
    <div
      className="group relative flex flex-col bg-white rounded-xl overflow-hidden border border-neutral-100 hover:shadow-xl transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container with 3:4 aspect ratio */}
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-neutral-100 cursor-pointer" onClick={() => onQuickView(product)}>
        <img
          src={displayImage}
          alt={lang === 'ar' ? product.title : product.titleEn}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Badges - Top Corner */}
        <div className="absolute top-2 start-2 flex flex-col gap-1 z-10">
          {product.discountPercent && (
            <span className="bg-defacto-red text-white text-[11px] font-black px-2 py-0.5 rounded shadow-sm">
              -{product.discountPercent}%
            </span>
          )}
          {product.badge && (
            <span className="bg-defacto-black text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
              {lang === 'ar' ? product.badge : product.badgeEn}
            </span>
          )}
        </div>

        {/* Wishlist Heart Icon */}
        <button
          onClick={e => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`absolute top-2 end-2 w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-xs transition-colors z-10 ${
            wishlisted
              ? 'bg-defacto-red text-white'
              : 'bg-white/80 hover:bg-white text-neutral-700'
          }`}
          aria-label="Wishlist"
        >
          <Heart className={`w-4 h-4 ${wishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Quick View Button on Hover */}
        <div className="absolute inset-x-2 bottom-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10 flex gap-1.5">
          <button
            onClick={e => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="flex-1 bg-white/95 hover:bg-white text-defacto-black font-bold text-xs py-2 px-3 rounded-lg shadow-md flex items-center justify-center gap-1 transition-colors"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{t.quickView}</span>
          </button>
          <button
            onClick={handleQuickAdd}
            className={`w-10 h-10 rounded-lg flex items-center justify-center text-white shadow-md transition-all ${
              addedAnimation ? 'bg-emerald-600' : 'bg-defacto-black hover:bg-neutral-800'
            }`}
            title={t.addToCart}
          >
            {addedAnimation ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Product Details (DeFacto Layout) */}
      <div className="p-3.5 flex flex-col flex-1">
        {/* Color Swatch Dots */}
        {product.colors.length > 1 && (
          <div className="flex items-center gap-1.5 mb-2">
            {product.colors.map((color, idx) => (
              <button
                key={idx}
                onClick={e => {
                  e.stopPropagation();
                  setSelectedColor(color);
                }}
                className={`w-3.5 h-3.5 rounded-full border transition-all ${
                  selectedColor.hex === color.hex
                    ? 'ring-2 ring-defacto-black ring-offset-1 scale-110'
                    : 'border-neutral-300 hover:scale-105'
                }`}
                style={{ backgroundColor: color.hex }}
                title={lang === 'ar' ? color.name : color.nameEn}
              />
            ))}
            <span className="text-[10px] text-neutral-400 ms-1">
              +{product.colors.length} {lang === 'ar' ? 'ألوان' : 'colors'}
            </span>
          </div>
        )}

        {/* Category Label */}
        <span className="text-[11px] text-neutral-400 font-medium mb-1">
          {lang === 'ar' ? product.categoryLabelAr : product.categoryLabelEn}
        </span>

        {/* Product Title */}
        <h3
          onClick={() => onQuickView(product)}
          className="text-xs sm:text-sm font-semibold text-neutral-800 hover:text-defacto-red line-clamp-2 cursor-pointer transition-colors mb-2 flex-1"
        >
          {lang === 'ar' ? product.title : product.titleEn}
        </h3>

        {/* Rating & Reviews */}
        <div className="flex items-center gap-1 mb-2 text-xs">
          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span className="font-bold text-neutral-800">{product.rating}</span>
          <span className="text-neutral-400 text-[10px]">({product.reviewsCount})</span>
        </div>

        {/* Price Row */}
        <div className="flex items-baseline gap-2 pt-1 border-t border-neutral-100">
          <span className="text-base font-extrabold text-defacto-black">
            {product.price} {t.egp}
          </span>
          {product.originalPrice && (
            <span className="text-xs text-neutral-400 line-through">
              {product.originalPrice} {t.egp}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
