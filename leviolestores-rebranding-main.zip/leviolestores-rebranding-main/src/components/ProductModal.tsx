import React, { useState } from 'react';
import { Product, ProductColor } from '../data/products';
import { useCart } from '../context/CartContext';
import { X, Star, Heart, ShieldCheck, Truck, RefreshCw, ShoppingBag, Check } from 'lucide-react';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({ product, onClose }) => {
  const { lang, addToCart, toggleWishlist, isWishlisted, t } = useCart();
  const [selectedImage, setSelectedImage] = useState<number>(0);
  const [selectedColor, setSelectedColor] = useState<ProductColor | null>(null);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  if (!product) return null;

  const currentColor = selectedColor || product.colors[0];
  const currentSize = selectedSize || product.sizes[0];
  const wishlisted = isWishlisted(product.id);

  const handleAddToCart = () => {
    addToCart(product, currentColor, currentSize, quantity);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Box */}
      <div className="relative bg-white w-full max-w-4xl max-h-[90vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row z-10 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 end-4 w-9 h-9 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-600 flex items-center justify-center z-20 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Gallery / Left Side */}
        <div className="w-full md:w-1/2 p-6 bg-neutral-50 flex flex-col justify-between">
          <div className="relative aspect-[3/4] w-full rounded-xl overflow-hidden bg-white shadow-inner mb-4">
            <img
              src={product.images[selectedImage] || currentColor.image}
              alt={lang === 'ar' ? product.title : product.titleEn}
              className="w-full h-full object-cover object-center"
            />
            {product.discountPercent && (
              <span className="absolute top-3 start-3 bg-defacto-red text-white text-xs font-black px-2.5 py-1 rounded">
                -{product.discountPercent}%
              </span>
            )}
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-2 justify-center">
              {product.images.map((img, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`w-14 h-18 rounded-lg overflow-hidden border-2 transition-all ${
                    selectedImage === index ? 'border-defacto-black ring-1 ring-defacto-black' : 'border-neutral-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details / Right Side */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 overflow-y-auto flex flex-col justify-between">
          <div>
            {/* Category & Rating */}
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                {lang === 'ar' ? product.categoryLabelAr : product.categoryLabelEn}
              </span>
              <div className="flex items-center gap-1 text-xs">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span className="font-bold text-neutral-800">{product.rating}</span>
                <span className="text-neutral-400">({product.reviewsCount} {t.reviews})</span>
              </div>
            </div>

            {/* Title */}
            <h2 className="text-xl sm:text-2xl font-black text-defacto-black mb-3">
              {lang === 'ar' ? product.title : product.titleEn}
            </h2>

            {/* Pricing */}
            <div className="flex items-baseline gap-3 mb-4">
              <span className="text-2xl sm:text-3xl font-black text-defacto-red">
                {product.price} {t.egp}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-neutral-400 line-through font-semibold">
                  {product.originalPrice} {t.egp}
                </span>
              )}
              {product.discountPercent && (
                <span className="text-xs bg-red-50 text-defacto-red font-bold px-2 py-0.5 rounded">
                  {t.save} {product.originalPrice! - product.price} {t.egp}
                </span>
              )}
            </div>

            {/* Fabric Specification */}
            <div className="mb-4 text-xs text-neutral-600 bg-neutral-100 p-2.5 rounded-lg flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span>
                <strong>{t.material}: </strong>
                {lang === 'ar' ? product.material : product.materialEn}
              </span>
            </div>

            {/* Color Selection */}
            <div className="mb-5">
              <div className="flex items-center justify-between text-xs font-bold text-neutral-700 mb-2">
                <span>{t.color}:</span>
                <span className="text-neutral-500 font-normal">
                  {lang === 'ar' ? currentColor.name : currentColor.nameEn}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((color, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedColor(color)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all ${
                      currentColor.hex === color.hex
                        ? 'border-defacto-black bg-neutral-900 text-white'
                        : 'border-neutral-200 hover:border-neutral-400 text-neutral-700'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-white/50"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span>{lang === 'ar' ? color.name : color.nameEn}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div className="mb-6">
              <div className="flex items-center justify-between text-xs font-bold text-neutral-700 mb-2">
                <span>{t.size}:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((sz, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedSize(sz)}
                    className={`min-w-[44px] px-3 py-2 rounded-lg border text-xs font-bold transition-all ${
                      currentSize === sz
                        ? 'border-defacto-red bg-defacto-red text-white'
                        : 'border-neutral-200 text-neutral-700 hover:border-neutral-400'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed mb-6">
              {lang === 'ar' ? product.descriptionAr : product.descriptionEn}
            </p>
          </div>

          {/* Action Row */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              {/* Quantity */}
              <div className="flex items-center border border-neutral-300 rounded-xl overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-11 flex items-center justify-center hover:bg-neutral-100 font-bold text-sm"
                >
                  -
                </button>
                <span className="w-10 text-center font-bold text-sm">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-11 flex items-center justify-center hover:bg-neutral-100 font-bold text-sm"
                >
                  +
                </button>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={handleAddToCart}
                disabled={addedSuccess}
                className={`flex-1 h-11 rounded-xl font-bold text-sm flex items-center justify-center gap-2 text-white transition-all shadow-md ${
                  addedSuccess ? 'bg-emerald-600' : 'bg-defacto-black hover:bg-neutral-800'
                }`}
              >
                {addedSuccess ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>تمت الإضافة بنجاح!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>{t.addToCart}</span>
                  </>
                )}
              </button>

              {/* Wishlist Button */}
              <button
                onClick={() => toggleWishlist(product.id)}
                className={`w-11 h-11 rounded-xl border flex items-center justify-center transition-colors ${
                  wishlisted
                    ? 'border-defacto-red bg-red-50 text-defacto-red'
                    : 'border-neutral-300 hover:border-neutral-400 text-neutral-600'
                }`}
              >
                <Heart className={`w-5 h-5 ${wishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Value Guarantees */}
            <div className="grid grid-cols-2 gap-2 pt-3 border-t border-neutral-100 text-[11px] text-neutral-500">
              <div className="flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-defacto-red" />
                <span>توصيل سريع لكل المحافظات</span>
              </div>
              <div className="flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5 text-defacto-red" />
                <span>استبدال واسترجاع خلال 14 يوم</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
