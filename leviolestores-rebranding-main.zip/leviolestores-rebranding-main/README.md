# Le Voile Stores (DeFacto Egypt Modern Redesign)

A modern, high-performance e-commerce frontend redesign for **Le Voile Stores** (Egypt's prominent modest fashion brand) adopting the sleek visual architecture and user experience of **DeFacto Egypt** ([defacto.com.eg](https://www.defacto.com.eg/)).

Designed to be hosted with zero hassle directly on **GitHub Pages**.

---

## 🌟 Key Features

1. **DeFacto E-Commerce DNA**:
   - Clean, high-contrast black/white/red (`#e11900`) aesthetic with typography (Cairo & Montserrat).
   - Top promotional banner strip with language toggle and free shipping announcements.
   - Story highlights circles for trending drops and seasonal campaigns.
   - Full-width hero fashion carousel with animated badges and CTAs.
   - 4-column responsive grid with portrait cards (aspect-ratio 3:4).
   - Color swatch dots that switch product images dynamically.
   - Hover image flip and quick view.
   - Faceted filtering (fabric type, deals only, category, sorting).

2. **Interactive Shopping Experience**:
   - Slide-over Shopping Bag drawer (Cart Drawer) with real-time free shipping threshold progress bar.
   - Coupon code engine (`VOILE10` for 10% discount).
   - Wishlist counter and interactive heart toggles.
   - Quick View Modal with multiple angle photos, sizes, fabric specs, and stock indicators.

3. **Bilingual & Responsive**:
   - Native Arabic (RTL) and English (LTR) toggle.
   - Mobile-first responsive navigation with drawer menu.

---

## 🚀 How to Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev

# 3. Build for production (GitHub Pages)
npm run build

# 4. Preview the built dist
npm run preview
```

---

## 📦 Deploying to GitHub Pages

1. Create a repository on GitHub and push the code:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Le Voile DeFacto frontend"
   git branch -M main
   git remote add origin https://github.com/<YOUR_USERNAME>/<YOUR_REPO_NAME>.git
   git push -u origin main
   ```
2. Go to your GitHub repository **Settings** -> **Pages**.
3. Under **Build and deployment**, select **GitHub Actions** as the source.
4. The included `.github/workflows/deploy.yml` workflow will automatically build and publish your site!
