/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        defacto: {
          red: '#e11900',
          darkRed: '#be1300',
          black: '#191919',
          dark: '#222222',
          gray: '#f5f5f5',
          border: '#e5e5e5',
          muted: '#767676',
        },
        levoile: {
          purple: '#9e197e',
          plum: '#6c0e56',
          gold: '#c5a85c',
        }
      },
      fontFamily: {
        sans: ['Cairo', 'Montserrat', 'sans-serif'],
        cairo: ['Cairo', 'sans-serif'],
        montserrat: ['Montserrat', 'sans-serif'],
      },
      aspectRatio: {
        '3/4': '3 / 4',
      }
    },
  },
  plugins: [],
}
